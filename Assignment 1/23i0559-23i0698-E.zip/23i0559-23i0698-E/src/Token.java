package tokens;

/**
 * Token Class
 * Represents a single token recognized by the lexical analyzer
 * 
 * @author Ruhab (23i-0559), Hasan (23i-0698)
 * @course CS4031 - Compiler Construction
 * @assignment Assignment 1 - Lexical Analyzer
 */

public class Token {
    private TokenType type;
    private String lexeme;
    private int lineNumber;
    private int columnNumber;
    
    /**
     * Constructor for Token
     * @param type The type of the token
     * @param lexeme The actual string value
     * @param lineNumber Line number where token appears
     * @param columnNumber Column number where token starts
     */
    public Token(TokenType type, String lexeme, int lineNumber, int columnNumber) {
        this.type = type;
        this.lexeme = lexeme;
        this.lineNumber = lineNumber;
        this.columnNumber = columnNumber;
    }
    
    // Getters
    public TokenType getType() {
        return type;
    }
    
    public String getLexeme() {
        return lexeme;
    }
    
    public int getLineNumber() {
        return lineNumber;
    }
    
    public int getColumnNumber() {
        return columnNumber;
    }
    
    /**
     * Returns formatted string representation of the token
     * Format: <TOKEN_TYPE, "lexeme", Line: X, Col: Y>
     */
    @Override
    public String toString() {
        return String.format("<%s, \"%s\", Line: %d, Col: %d>",
            type.toString(),
            lexeme,
            lineNumber,
            columnNumber
        );
    }
    
    /**
     * Checks if this token is of a specific type
     */
    public boolean isOfType(TokenType type) {
        return this.type == type;
    }
    
    /**
     * Checks if this token is a keyword
     */
    public boolean isKeyword() {
        return type == TokenType.KEYWORD;
    }
    
    /**
     * Checks if this token is an identifier
     */
    public boolean isIdentifier() {
        return type == TokenType.IDENTIFIER;
    }
    
    /**
     * Checks if this token is a literal
     */
    public boolean isLiteral() {
        return type == TokenType.INTEGER_LITERAL ||
               type == TokenType.FLOAT_LITERAL ||
               type == TokenType.STRING_LITERAL ||
               type == TokenType.CHAR_LITERAL ||
               type == TokenType.BOOLEAN_LITERAL;
    }
    
    /**
     * Checks if this token is an operator
     */
    public boolean isOperator() {
        return type == TokenType.ARITHMETIC_OP ||
               type == TokenType.RELATIONAL_OP ||
               type == TokenType.LOGICAL_OP ||
               type == TokenType.ASSIGNMENT_OP ||
               type == TokenType.INCREMENT_OP ||
               type == TokenType.DECREMENT_OP;
    }
}