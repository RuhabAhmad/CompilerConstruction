/**
 * JFlex Scanner Specification for NEXUS Language (Fixed for Test File 3)
 * Handles strings, character literals, escape sequences, and robust error reporting.
 *
 * Authors: Ruhab (23i-0559), Hasan (23i-0698)
 * Course: CS4031 - Compiler Construction
 */

import java.io.*;

%%

%class Yylex
%public
%line
%column
%type Token

%{

    private int tokenCount = 0;
    private int lineCount = 1;
    private int commentCount = 0;
    
    private SymbolTable symbolTable = new SymbolTable();
    private ErrorHandler errorHandler = new ErrorHandler();
    
    private Token createToken(TokenType type, String lexeme) {
        tokenCount++;
        if (type == TokenType.IDENTIFIER) {
            symbolTable.addIdentifier(lexeme, yyline + 1);
        }
        return new Token(type, lexeme, yyline + 1, yycolumn + 1);
    }
    
    private Token reportError(String lexeme, String reason) {
        errorHandler.reportError("LEXICAL_ERROR", lexeme, yyline + 1, yycolumn + 1, reason);
        return null;
    }

    public int getTokenCount() { return tokenCount; }
    public int getLineCount() { return lineCount; }
    public int getCommentCount() { return commentCount; }
    public SymbolTable getSymbolTable() { return symbolTable; }
    public ErrorHandler getErrorHandler() { return errorHandler; }

%}

/* ==================== MACRO DEFINITIONS ==================== */
DIGIT = [0-9]
UPPERCASE = [A-Z]
LOWERCASE = [a-z]
LETTER = [a-zA-Z]
UNDERSCORE = "_"
WHITESPACE = [ \t\r\n]+
NEWLINE = \r|\n|\r\n

/* Keywords */
KEYWORD = start|finish|loop|condition|declare|output|input|function|return|break|continue|else

/* Boolean literals */
BOOLEAN = true|false

/* Identifiers: Uppercase start, max 31 chars */
IDENTIFIER = {UPPERCASE}[a-z0-9_]{0,30}

/* Numeric literals */
INTEGER = [+-]?{DIGIT}+
FLOAT = [+-]?{DIGIT}+\.{DIGIT}{1,6}([eE][+-]?{DIGIT}+)?  

/* Strings and chars (robust escape handling) */
STRING = \"([^\\\"\n\r]|\\[btnr\"'\\])*\" 
CHAR   = \'([^\\\'\n\r]|\\[btnr\'\\])\'

/* Comments */
SINGLE_COMMENT = "##".*
MULTI_COMMENT = "#*"([^*]|\*+[^#])*\*+"#"

/* Operators */
EXPONENT = \*\*
EQ = ==
NEQ = \!=
LTE = <=
GTE = >=
AND = &&
OR = \|\|
INC = \+\+
DEC = --
PLUS_EQ = \+=
MINUS_EQ = -=
MULT_EQ = \*=
DIV_EQ = /=

PLUS = \+
MINUS = -
MULT = \*
DIV = /
MOD = %
LT = <
GT = >
ASSIGN = =
NOT = !

/* Punctuators */
LPAREN = \(
RPAREN = \)
LBRACE = \{
RBRACE = \}
LBRACKET = \[
RBRACKET = \]
COMMA = ,
SEMICOLON = ;
COLON = :

/* ==================== LEXICAL RULES ==================== */
%%

/* -------------------- COMMENTS -------------------- */
{MULTI_COMMENT}     { commentCount++; }
{SINGLE_COMMENT}    { commentCount++; }

/* -------------------- WHITESPACE -------------------- */
{NEWLINE}           { lineCount++; }
{WHITESPACE}        { /* skip */ }

/* -------------------- OPERATORS -------------------- */
{EXPONENT}          { return createToken(TokenType.ARITHMETIC_OP, yytext()); }
{EQ}                { return createToken(TokenType.RELATIONAL_OP, yytext()); }
{NEQ}               { return createToken(TokenType.RELATIONAL_OP, yytext()); }
{LTE}               { return createToken(TokenType.RELATIONAL_OP, yytext()); }
{GTE}               { return createToken(TokenType.RELATIONAL_OP, yytext()); }
{AND}               { return createToken(TokenType.LOGICAL_OP, yytext()); }
{OR}                { return createToken(TokenType.LOGICAL_OP, yytext()); }
{INC}               { return createToken(TokenType.INCREMENT_OP, yytext()); }
{DEC}               { return createToken(TokenType.DECREMENT_OP, yytext()); }
{PLUS_EQ}           { return createToken(TokenType.ASSIGNMENT_OP, yytext()); }
{MINUS_EQ}          { return createToken(TokenType.ASSIGNMENT_OP, yytext()); }
{MULT_EQ}           { return createToken(TokenType.ASSIGNMENT_OP, yytext()); }
{DIV_EQ}            { return createToken(TokenType.ASSIGNMENT_OP, yytext()); }

{PLUS}              { return createToken(TokenType.ARITHMETIC_OP, yytext()); }
{MINUS}             { return createToken(TokenType.ARITHMETIC_OP, yytext()); }
{MULT}              { return createToken(TokenType.ARITHMETIC_OP, yytext()); }
{DIV}               { return createToken(TokenType.ARITHMETIC_OP, yytext()); }
{MOD}               { return createToken(TokenType.ARITHMETIC_OP, yytext()); }
{LT}                { return createToken(TokenType.RELATIONAL_OP, yytext()); }
{GT}                { return createToken(TokenType.RELATIONAL_OP, yytext()); }
{ASSIGN}            { return createToken(TokenType.ASSIGNMENT_OP, yytext()); }
{NOT}               { return createToken(TokenType.LOGICAL_OP, yytext()); }

/* -------------------- KEYWORDS & BOOLEAN -------------------- */
{KEYWORD}           { return createToken(TokenType.KEYWORD, yytext()); }
{BOOLEAN}           { return createToken(TokenType.BOOLEAN_LITERAL, yytext()); }

/* -------------------- IDENTIFIERS -------------------- */
{IDENTIFIER}        { return createToken(TokenType.IDENTIFIER, yytext()); }

/* Catch invalid identifiers (starting lowercase or digit) */
[a-z][a-zA-Z0-9_]*  { return reportError(yytext(), "Identifier must start with uppercase letter"); }
[0-9][a-zA-Z0-9_]*  { return reportError(yytext(), "Identifier cannot start with digit"); }

/* -------------------- NUMERIC LITERALS -------------------- */
{FLOAT}             { return createToken(TokenType.FLOAT_LITERAL, yytext()); }
{INTEGER}           { return createToken(TokenType.INTEGER_LITERAL, yytext()); }

/* Malformed floats */
[+-]?{DIGIT}+\.(?!{DIGIT})[0-9]*        { return reportError(yytext(), "Malformed float literal"); }
[+-]?{DIGIT}+\.[0-9]{7,}                { return reportError(yytext(), "Float literal exceeds 6 decimals"); }
[+-]?{DIGIT}+\.{DIGIT}+([eE][^0-9+-].*)? { return reportError(yytext(), "Invalid float exponent"); }

/* -------------------- STRING LITERALS -------------------- */
\"([^\\\"\n\r]|\\[btnr\"'\\])*\"  { return createToken(TokenType.STRING_LITERAL, yytext()); }
\"([^\\\"]|\\.)*                   { return reportError(yytext(), "Unterminated string literal"); }
\".*\n                              { return reportError(yytext(), "String contains unescaped newline"); }

/* -------------------- CHARACTER LITERALS -------------------- */
\'([^\\\'\n\r]|\\[btnr\'\\])\'     { return createToken(TokenType.CHAR_LITERAL, yytext()); }
\'{0}\'                            { return reportError(yytext(), "Empty character literal"); }
\'([^\\\'\n\r]|\\[btnr\'\\]){2,}\' { return reportError(yytext(), "Multiple characters in char literal"); }
\'.*                               { return reportError(yytext(), "Unterminated character literal"); }

/* -------------------- PUNCTUATORS -------------------- */
{LPAREN}|{RPAREN}|{LBRACE}|{RBRACE}|{LBRACKET}|{RBRACKET}|{COMMA}|{SEMICOLON}|{COLON} 
                    { return createToken(TokenType.PUNCTUATOR, yytext()); }

/* -------------------- CATCH-ALL INVALID -------------------- */
. { 
    // Catch any single unknown character
    reportError(yytext(), "Unknown symbol"); 
}

/* -------------------- EOF -------------------- */
<<EOF>>             { return createToken(TokenType.EOF, ""); }